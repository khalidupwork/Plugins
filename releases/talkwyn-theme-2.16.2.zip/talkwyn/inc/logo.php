<?php
/**
 * Inline, theme-aware Talkwyn logo (outlined paths from brand/logo/talkwyn-logo.svg).
 * Colors come from CSS classes, so one markup works on white and on Ink.
 *
 * @package Talkwyn
 */

defined( 'ABSPATH' ) || exit;

/**
 * Logo SVG markup.
 *
 * @param string $variant full|mark.
 * @param string $label   Accessible label.
 */
function talkwyn_logo_svg( string $variant = 'full', string $label = 'Talkwyn' ): string {
	if ( 'mark' === $variant ) {
		return '<svg class="tw-logo tw-logo--mark" viewBox="0 0 64 64" width="32" height="32" role="img" aria-label="' . esc_attr( $label ) . '" focusable="false"><path class="tw-logo__mark" d="M14 6h36a10 10 0 0 1 10 10v24a10 10 0 0 1-10 10H26l-12 9v-9a10 10 0 0 1-10-10V16A10 10 0 0 1 14 6z"/><circle class="tw-logo__dot" cx="19" cy="36" r="5"/><circle class="tw-logo__dot" cx="32" cy="29" r="5"/><circle class="tw-logo__win" cx="45" cy="20" r="6"/></svg>';
	}
	return '<svg class="tw-logo" viewBox="0 0 278.6 66.0" width="139" height="33" role="img" aria-label="' . esc_attr( $label ) . '" focusable="false"><g transform="translate(0 0) scale(1)"><path d="M14 6h36a10 10 0 0 1 10 10v24a10 10 0 0 1-10 10H26l-12 9v-9a10 10 0 0 1-10-10V16A10 10 0 0 1 14 6z" class="tw-logo__mark"/><circle cx="19" cy="36" r="5" class="tw-logo__dot"/><circle cx="32" cy="29" r="5" class="tw-logo__dot"/><circle cx="45" cy="20" r="6" class="tw-logo__win"/></g><g transform="translate(79.04887714663144 50) scale(0.052840158520475564)"><path d="M318.0 6Q219.0 6 164.5 -47.5Q110.0 -101 110.0 -197V-416H18.0V-546H23.0Q65.0 -546 87.5 -567.0Q110.0 -588 110.0 -630V-670H260.0V-546H388.0V-416H260.0V-207Q260.0 -179 270.0 -160.5Q280.0 -142 301.0 -133.0Q322.0 -124 353.0 -124Q360.0 -124 369.0 -125.0Q378.0 -126 388.0 -127V0Q373.0 2 354.0 4.0Q335.0 6 318.0 6Z" class="tw-logo__talk"/><path d="M615.0 12Q556.0 12 513.0 -7.0Q470.0 -26 447.0 -61.5Q424.0 -97 424.0 -146Q424.0 -192 445.0 -227.5Q466.0 -263 509.5 -287.0Q553.0 -311 618.0 -321L785.0 -348V-238L645.0 -213Q613.0 -207 596.0 -192.5Q579.0 -178 579.0 -151Q579.0 -126 598.0 -112.0Q617.0 -98 645.0 -98Q682.0 -98 710.0 -114.0Q738.0 -130 753.5 -157.5Q769.0 -185 769.0 -218V-360Q769.0 -391 744.5 -412.0Q720.0 -433 678.0 -433Q638.0 -433 607.5 -411.0Q577.0 -389 563.0 -353L443.0 -410Q459.0 -456 494.0 -489.0Q529.0 -522 578.0 -540.0Q627.0 -558 685.0 -558Q754.0 -558 807.0 -533.0Q860.0 -508 889.5 -463.5Q919.0 -419 919.0 -360V0H779.0V-88L813.0 -94Q789.0 -58 760.0 -34.5Q731.0 -11 695.0 0.5Q659.0 12 615.0 12Z" class="tw-logo__talk"/><path d="M999.0 0V-757H1149.0V0Z" class="tw-logo__talk"/><path d="M1229.0 0V-757H1379.0V-272L1323.0 -290L1564.0 -546H1749.0L1551.0 -326L1748.0 0H1578.0L1413.0 -277L1500.0 -299L1333.0 -117L1379.0 -204V0Z" class="tw-logo__talk"/><path d="M1929.0 0 1741.0 -546H1896.0L2028.0 -152L1974.0 -153L2121.0 -546H2251.0L2397.0 -153L2343.0 -152L2475.0 -546H2631.0L2442.0 0H2312.0L2160.0 -422H2212.0L2059.0 0Z" class="tw-logo__wyn"/><path d="M2752.0 220Q2728.0 220 2705.5 216.0Q2683.0 212 2666.0 203V80Q2680.0 84 2699.0 87.0Q2718.0 90 2734.0 90Q2778.0 90 2797.0 69.5Q2816.0 49 2828.0 23L2865.0 -62L2863.0 63L2623.0 -546H2784.0L2943.0 -113H2883.0L3042.0 -546H3203.0L2969.0 51Q2947.0 107 2915.0 145.0Q2883.0 183 2842.5 201.5Q2802.0 220 2752.0 220Z" class="tw-logo__wyn"/><path d="M3239.0 0V-546H3379.0V-438L3371.0 -462Q3390.0 -511 3432.5 -534.5Q3475.0 -558 3532.0 -558Q3594.0 -558 3640.5 -532.0Q3687.0 -506 3713.0 -459.5Q3739.0 -413 3739.0 -351V0H3589.0V-319Q3589.0 -351 3576.5 -374.0Q3564.0 -397 3541.5 -410.0Q3519.0 -423 3489.0 -423Q3460.0 -423 3437.0 -410.0Q3414.0 -397 3401.5 -374.0Q3389.0 -351 3389.0 -319V0Z" class="tw-logo__wyn"/></g></svg>';
}
